package com.statuspro.app

import android.content.ContentValues
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.media.MediaMetadataRetriever
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.setPadding
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import java.io.File
import java.io.FileInputStream
import java.text.DecimalFormat

class MainActivity : ComponentActivity() {
    private lateinit var info: TextView
    private lateinit var status: TextView
    private lateinit var convertButton: Button
    private var selectedUri: Uri? = null
    private var transformer: Transformer? = null
    private var outputFile: File? = null
    private lateinit var fpsSpinner: Spinner
    private lateinit var codecSpinner: Spinner
    private lateinit var audioCheck: CheckBox

    private val pickVideo = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            selectedUri = uri
            showVideoInfo(uri)
            convertButton.isEnabled = true
            status.text = "Video siap diproses."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24)
            setBackgroundColor(0xFF101820.toInt())
        }
        val title = TextView(this).apply {
            text = "STATUS PRO"
            textSize = 28f
            setTextColor(0xFFFFFFFF.toInt())
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        val subtitle = TextView(this).apply {
            text = "VIDEO OPTIMIZER  •  OFFLINE  •  v0.2"
            textSize = 12f
            setTextColor(0xFF8FA3B5.toInt())
        }
        val intro = TextView(this).apply {
            text = "Optimalkan video untuk WhatsApp Status tanpa watermark dan tanpa langganan."
            textSize = 16f
            setTextColor(0xFFE8EEF2.toInt())
            setPadding(0, 32, 0, 24)
        }
        val pickButton = Button(this).apply {
            text = "PILIH VIDEO"
            setOnClickListener { pickVideo.launch(arrayOf("video/*")) }
        }
        info = TextView(this).apply {
            text = "Belum ada video dipilih"
            textSize = 14f
            setTextColor(0xFFD6E0E8.toInt())
            setPadding(0, 20, 0, 20)
        }
        val modeTitle = TextView(this).apply {
            text = "MODE EKSPOR"
            textSize = 12f
            setTextColor(0xFF8FA3B5.toInt())
        }
        val mode = TextView(this).apply {
            text = "Ekspor fleksibel\nPilih FPS, codec, dan audio sesuai kebutuhan"
            textSize = 15f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 8, 0, 20)
        }
        val settingsTitle = TextView(this).apply {
            text = "PENGATURAN EKSPOR"
            textSize = 13f
            setTextColor(0xFFFFC247.toInt())
            setPadding(0, 12, 0, 8)
        }
        fpsSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("FPS Asli", "24 FPS", "25 FPS", "30 FPS"))
        }
        codecSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                if (android.os.Build.VERSION.SDK_INT >= 24) listOf("H.264 (kompatibel)", "H.265 (lebih efisien, jika didukung)") else listOf("H.264 (kompatibel)"))
        }
        audioCheck = CheckBox(this).apply {
            text = "Pertahankan audio asli"
            isChecked = true
            setTextColor(0xFFFFFFFF.toInt())
        }
        convertButton = Button(this).apply {
            text = "OPTIMALKAN VIDEO"
            isEnabled = false
            setOnClickListener { startExport() }
        }
        status = TextView(this).apply {
            text = "Hasil akan disimpan ke folder Movies/StatusPro."
            textSize = 13f
            setTextColor(0xFF8FA3B5.toInt())
            setPadding(0, 20, 0, 0)
        }
        val note = TextView(this).apply {
            text = "Catatan: FPS hanya membatasi frame rate maksimum; tidak menambah frame/interpolasi. H.265 bergantung dukungan encoder perangkat. Proses berjalan offline; hasil disimpan di Movies/StatusPro."
            textSize = 12f
            setTextColor(0xFF8FA3B5.toInt())
            setPadding(0, 32, 0, 0)
        }
        root.addView(title)
        root.addView(subtitle)
        root.addView(intro)
        root.addView(pickButton, matchWidth())
        root.addView(info)
        root.addView(modeTitle)
        root.addView(mode)
        root.addView(settingsTitle)
        root.addView(label("Frame rate output"))
        root.addView(fpsSpinner, matchWidth())
        root.addView(label("Format video"))
        root.addView(codecSpinner, matchWidth())
        root.addView(audioCheck)
        root.addView(convertButton, matchWidth())
        root.addView(status)
        root.addView(note)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun label(value: String) = TextView(this).apply {
        text = value
        textSize = 12f
        setTextColor(0xFF8FA3B5.toInt())
        setPadding(0, 12, 0, 4)
    }

    private fun matchWidth() = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)

    private fun showVideoInfo(uri: Uri) {
        try {
            val retriever = MediaMetadataRetriever()
            retriever.setDataSource(this, uri)
            val width = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH) ?: "?"
            val height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT) ?: "?"
            val duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            val size = contentResolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: -1L
            retriever.release()
            info.text = "Video dipilih\nResolusi: ${width} × ${height}\nDurasi: ${duration / 1000} detik\nUkuran: ${if (size >= 0) formatBytes(size) else "tidak diketahui"}"
        } catch (e: Exception) {
            info.text = "Video dipilih. Detail file tidak dapat dibaca, tetapi proses dapat dicoba."
        }
    }

    private fun startExport() {
        val uri = selectedUri ?: return
        convertButton.isEnabled = false
        status.text = "Menyiapkan konversi…"
        val out = File(cacheDir, "statuspro_${System.currentTimeMillis()}.mp4")
        outputFile = out
        val mediaItem = MediaItem.fromUri(uri)
        val selectedFps = when (fpsSpinner.selectedItemPosition) {
            1 -> 24
            2 -> 25
            3 -> 30
            else -> 0
        }
        val editedBuilder = EditedMediaItem.Builder(mediaItem)
            .setRemoveAudio(!audioCheck.isChecked)
        if (selectedFps > 0) editedBuilder.setFrameRate(selectedFps)
        val item = editedBuilder.build()
        val selectedMime = if (codecSpinner.selectedItemPosition == 1 && android.os.Build.VERSION.SDK_INT >= 24) MimeTypes.VIDEO_H265 else MimeTypes.VIDEO_H264
        val listener = object : Transformer.Listener {
            override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                try {
                    saveToGallery(out)
                    status.text = "Selesai! Video tersimpan di Movies/StatusPro."
                    Toast.makeText(this@MainActivity, "Video berhasil disimpan", Toast.LENGTH_LONG).show()
                } catch (e: Exception) {
                    status.text = "Konversi selesai, tetapi gagal menyimpan: ${e.localizedMessage}"
                } finally {
                    convertButton.isEnabled = true
                    transformer = null
                }
            }

            override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                status.text = "Konversi gagal: ${exportException.localizedMessage ?: "format tidak didukung perangkat"}"
                convertButton.isEnabled = true
                transformer = null
            }
        }
        try {
            transformer = Transformer.Builder(this)
                .setVideoMimeType(selectedMime)
                .addListener(listener)
                .build()
            transformer?.start(item, out.absolutePath)
            status.text = "Sedang mengoptimalkan video… Jangan tutup aplikasi."
        } catch (e: Exception) {
            status.text = "Tidak dapat memulai konversi: ${e.localizedMessage}"
            convertButton.isEnabled = true
            transformer = null
        }
    }

    private fun saveToGallery(file: File) {
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "StatusPro_${System.currentTimeMillis()}.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/StatusPro")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("Tidak dapat membuat file di galeri")
        try {
            contentResolver.openOutputStream(uri)?.use { output -> FileInputStream(file).use { input -> input.copyTo(output) } }
                ?: throw IllegalStateException("Tidak dapat menulis file")
            values.clear()
            values.put(MediaStore.Video.Media.IS_PENDING, 0)
            contentResolver.update(uri, values, null, null)
        } catch (e: Exception) {
            contentResolver.delete(uri, null, null)
            throw e
        } finally {
            file.delete()
        }
    }

    private fun formatBytes(bytes: Long): String {
        val mb = bytes / (1024.0 * 1024.0)
        return "${DecimalFormat("0.0").format(mb)} MB"
    }

    override fun onDestroy() {
        super.onDestroy()
        // Transformer exports are intentionally not left running after this simple MVP screen is destroyed.
        transformer?.cancel()
    }
}
