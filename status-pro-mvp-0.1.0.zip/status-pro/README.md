# STATUS PRO 0.2.0

Aplikasi Android offline untuk mengonversi video ke MP4 menggunakan Android Media3 Transformer.

## Fitur 0.2.0
- Pilih video dari galeri / penyimpanan.
- Informasi resolusi, durasi, dan ukuran file sumber.
- Pilihan output FPS: asli, 24, 25, atau 30 FPS. Pilihan FPS membatasi frame rate maksimum; tidak melakukan frame interpolation.
- Pilihan codec H.264 atau H.265 (opsi H.265 hanya ditampilkan pada Android 7.0/API 24+; keberhasilan tetap bergantung encoder perangkat).
- Audio asli dapat dipertahankan atau dihapus.
- Hasil disimpan ke `Movies/StatusPro`.
- Ikon launcher STATUS PRO sudah disertakan.

## Batasan yang diketahui
- Belum ada kontrol resolusi dan bitrate manual.
- Belum ada AI super-resolution / denoise; semua proses berjalan lokal dengan encoder perangkat.
- Tidak menjanjikan H.265 tersedia pada semua perangkat. Jika ekspor gagal, pilih H.264.
- Kualitas dan kecepatan ekspor bergantung pada codec hardware perangkat.

## Build APK melalui GitHub Actions
1. Upload isi folder `status-pro` ke repository GitHub (jangan upload ZIP ini sebagai satu file).
2. Pastikan workflow ada di `.github/workflows/build-apk.yml`.
3. Buka tab **Actions** di repository.
4. Pilih **Build Status Pro APK** lalu tekan **Run workflow** (atau lakukan commit ke branch `main`).
5. Setelah proses selesai dengan tanda centang hijau, buka hasil workflow dan unduh artifact `status-pro-debug-apk`.
6. Ekstrak ZIP artifact, lalu pasang `app-debug.apk` di Android.

## Versi
- applicationId: `com.statuspro.app`
- versionCode: 2
- versionName: 0.2.0
- minSdk: 23
