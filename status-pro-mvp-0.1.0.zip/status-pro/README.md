# STATUS PRO — Android MVP 0.1.0

Aplikasi Android offline untuk menguji alur pemilihan video, transcode MP4/H.264 menggunakan AndroidX Media3 Transformer, dan menyimpan hasil ke `Movies/StatusPro`.

## Status fitur
- [x] Pilih video melalui Android Photo Picker / document picker
- [x] Baca metadata dasar (resolusi, durasi, ukuran)
- [x] Ekspor ulang ke MP4/H.264 menggunakan Media3 Transformer
- [x] Simpan hasil ke galeri tanpa watermark
- [ ] Smart bitrate adaptif dan target ukuran
- [ ] Preset WhatsApp Status yang tervalidasi
- [ ] Preview asli vs hasil
- [ ] Progress bar dan pembatalan yang lebih baik
- [ ] Batch processing
- [ ] Filter enhancement (sharpen/denoise/color)
- [ ] AI super-resolution (opsional, perangkat kompatibel)

## Catatan penting
Versi ini adalah kerangka MVP untuk memvalidasi pipeline Android. Menentukan H.264 sebagai output memaksa proses ekspor ke codec tersebut bila diperlukan, tetapi versi ini belum mengatur bitrate target secara adaptif dan belum membuktikan hasil lebih baik daripada PureStatus. Kualitas, ukuran, kompatibilitas, dan kecepatan harus diuji dengan kumpulan video yang sama di beberapa perangkat.

## Build APK melalui GitHub Actions
1. Buat repositori GitHub baru bernama `status-pro`.
2. Unggah seluruh isi folder proyek ini (bukan folder luarnya) ke repositori.
3. Buka tab **Actions** dan izinkan workflow jika diminta.
4. Jalankan **Build Status Pro APK** atau tunggu build otomatis setelah commit.
5. Setelah selesai, buka hasil workflow dan unduh artifact `status-pro-debug-apk`.

## Teknologi
- Kotlin
- AndroidX Media3 Transformer 1.11.1
- Android SDK compile 36, min SDK 23

Media3 dependencies follow the official Android documentation: https://developer.android.com/media/media3/transformer/getting-started
