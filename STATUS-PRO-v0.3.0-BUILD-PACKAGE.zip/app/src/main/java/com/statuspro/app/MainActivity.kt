package com.statuspro.app

import android.content.ContentValues
import android.net.Uri
import android.os.Bundle
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.media.MediaMetadataRetriever
import android.graphics.Typeface
import android.view.View
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.setPadding
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.transformer.*
import androidx.media3.effect.Presentation
import androidx.media3.effect.Brightness
import androidx.media3.effect.Contrast
import java.io.File
import java.io.FileInputStream
import java.text.DecimalFormat

@androidx.media3.common.util.UnstableApi
class MainActivity : ComponentActivity() {
    private val bg = 0xFF171717.toInt(); private val panel = 0xFF252525.toInt()
    private val orange = 0xFFFF7417.toInt(); private val white = 0xFFF7F7F7.toInt(); private val silver = 0xFFBFC3C7.toInt()
    private lateinit var info: TextView; private lateinit var status: TextView
    private lateinit var exportButton: Button; private lateinit var cancelButton: Button
    private lateinit var fps: Spinner; private lateinit var resolution: Spinner; private lateinit var codec: Spinner
    private lateinit var bitrate: Spinner; private lateinit var audio: CheckBox
    private lateinit var brightness: SeekBar; private lateinit var contrast: SeekBar
    private var selectedUri: Uri? = null; private var transformer: Transformer? = null; private var outputFile: File? = null
    private var originalWidth = 0; private var originalHeight = 0; private var originalDuration = 0L; private var originalSize = -1L

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) { selectedUri = uri; contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION); inspect(uri); exportButton.isEnabled = true; status.text = "Video siap diproses." }
    }
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); window.statusBarColor = bg; window.navigationBarColor = bg; buildUi() }

    private fun buildUi() {
        fun text(value:String, size:Float=14f, color:Int=white, bold:Boolean=false) = TextView(this).apply { text=value; textSize=size; setTextColor(color); if(bold) typeface=Typeface.DEFAULT_BOLD; setPadding(0,8,0,8) }
        fun heading(value:String) = text(value,13f,orange,true).apply { setPadding(0,18,0,6) }
        fun spinner(items:List<String>) = Spinner(this).apply { adapter=ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items) }
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(20); setBackgroundColor(bg) }
        root.addView(text("STATUS PRO",30f,orange,true)); root.addView(text("VIDEO OPTIMIZER  •  OFFLINE  •  v0.3",11f,silver,true))
        root.addView(text("Optimalkan video untuk WhatsApp Status. Semua proses dilakukan di perangkat, tanpa watermark.",14f,white))
        val pick = Button(this).apply { text="＋  PILIH VIDEO"; setTextColor(white); setBackgroundTintList(android.content.res.ColorStateList.valueOf(orange)); setOnClickListener { picker.launch(arrayOf("video/*")) } }
        root.addView(pick, lp()); info=text("Belum ada video dipilih",13f,silver).apply { setPadding(12,14,12,14); setBackgroundColor(panel) }; root.addView(info, lp())
        root.addView(heading("PRESET CEPAT")); val preset=spinner(listOf("Atur manual","WhatsApp Status • 720p","Kualitas tinggi • 1080p","Ukuran kecil • 480p","Seimbang • 720p")); root.addView(preset,lp())
        preset.onItemSelectedListener=object:AdapterView.OnItemSelectedListener { override fun onNothingSelected(p:AdapterView<*>?){}; override fun onItemSelected(p:AdapterView<*>?,v:View?,pos:Int,id:Long){ when(pos){1->{resolution.setSelection(1);fps.setSelection(3);bitrate.setSelection(1);codec.setSelection(0)};2->{resolution.setSelection(2);fps.setSelection(3);bitrate.setSelection(2);codec.setSelection(0)};3->{resolution.setSelection(0);fps.setSelection(3);bitrate.setSelection(0);codec.setSelection(0)};4->{resolution.setSelection(1);fps.setSelection(3);bitrate.setSelection(1);codec.setSelection(0}} } }
        root.addView(heading("PENGATURAN VIDEO")); root.addView(text("Resolusi output",12f,silver)); resolution=spinner(listOf("480p • hemat","720p • direkomendasikan","1080p • kualitas tinggi","Asli")); root.addView(resolution,lp())
        root.addView(text("Frame rate",12f,silver)); fps=spinner(listOf("Asli","24 FPS","25 FPS","30 FPS")); root.addView(fps,lp())
        root.addView(text("Bitrate video",12f,silver)); bitrate=spinner(listOf("1.5 Mbps • kecil","3 Mbps • seimbang","6 Mbps • tinggi","8 Mbps • sangat tinggi","Otomatis")); root.addView(bitrate,lp())
        root.addView(text("Codec",12f,silver)); codec=spinner(if(Build.VERSION.SDK_INT>=24) listOf("H.264 • paling kompatibel","H.265 • lebih efisien") else listOf("H.264 • paling kompatibel")); root.addView(codec,lp())
        audio=CheckBox(this).apply { text="Pertahankan audio asli"; isChecked=true; setTextColor(white); buttonTintList=android.content.res.ColorStateList.valueOf(orange) }; root.addView(audio)
        root.addView(heading("PENINGKATAN GAMBAR")); root.addView(text("Kecerahan",12f,silver)); brightness=SeekBar(this).apply { max=20; progress=10; progressTintList=android.content.res.ColorStateList.valueOf(orange); thumbTintList=android.content.res.ColorStateList.valueOf(orange) }; root.addView(brightness,lp())
        root.addView(text("Kontras",12f,silver)); contrast=SeekBar(this).apply { max=20; progress=10; progressTintList=android.content.res.ColorStateList.valueOf(orange); thumbTintList=android.content.res.ColorStateList.valueOf(orange) }; root.addView(contrast,lp())
        root.addView(text("Pengaturan gambar memakai pemrosesan GPU; gunakan seperlunya agar POCO M3 tetap stabil.",11f,silver))
        exportButton=Button(this).apply { text="OPTIMALKAN VIDEO"; isEnabled=false; setTextColor(white); setBackgroundTintList(android.content.res.ColorStateList.valueOf(orange)); setOnClickListener { startExport() } }; root.addView(exportButton,lp())
        cancelButton=Button(this).apply { text="BATALKAN PROSES"; visibility=View.GONE; setOnClickListener { transformer?.cancel(); transformer=null; outputFile?.delete(); status.text="Proses dibatalkan."; exportButton.isEnabled=selectedUri!=null; visibility=View.GONE } }; root.addView(cancelButton,lp())
        status=text("Hasil tersimpan di Galeri → Movies/StatusPro",13f,silver); root.addView(status)
        root.addView(text("Catatan: AI enhancement generatif tidak diaktifkan karena POCO M3 tidak memiliki akselerator AI yang memadai. Fitur gambar di atas adalah penyesuaian kecerahan dan kontras, bukan AI.",11f,silver))
        setContentView(ScrollView(this).apply { isFillViewport=true; addView(root) })
    }
    private fun lp()=LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=5 }
    private fun inspect(uri:Uri) { try { MediaMetadataRetriever().also { r->r.setDataSource(this,uri); originalWidth=r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull()?:0; originalHeight=r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull()?:0; originalDuration=r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()?:0L; r.release() }; originalSize=contentResolver.openAssetFileDescriptor(uri,"r")?.use{it.length}?:-1L; info.text="VIDEO DIPILIH\nResolusi: ${originalWidth} × ${originalHeight}\nDurasi: ${originalDuration/1000} detik\nUkuran: ${if(originalSize>=0)bytes(originalSize) else "tidak diketahui"}\nRekomendasi: ${if(originalHeight>720)"720p / 3 Mbps" else "Pertahankan resolusi / 3 Mbps"}" } catch(e:Exception){ info.text="Video dipilih. Detail tidak terbaca; proses tetap dapat dicoba." } }

    private fun startExport() {
        val uri=selectedUri?:return; exportButton.isEnabled=false; cancelButton.visibility=View.VISIBLE; status.text="Menyiapkan proses…"
        val out=File(cacheDir,"statuspro_${System.currentTimeMillis()}.mp4"); outputFile=out
        val targetHeight=when(resolution.selectedItemPosition){0->480;1->720;2->1080;else->0}
        val selectedFps=when(fps.selectedItemPosition){1->24;2->25;3->30;else->0}
        val bps=when(bitrate.selectedItemPosition){0->1_500_000;1->3_000_000;2->6_000_000;3->8_000_000;else->0}
        val effects=mutableListOf<androidx.media3.common.Effect>()
        if(targetHeight>0) effects.add(Presentation.createForHeight(targetHeight))
        val bright=(brightness.progress-10)/100f; val cont=(contrast.progress-10)/10f
        if(bright!=0f) effects.add(Brightness(bright)); if(cont!=0f) effects.add(Contrast(cont))
        val edited=EditedMediaItem.Builder(MediaItem.fromUri(uri)).setRemoveAudio(!audio.isChecked).apply { if(selectedFps>0)setFrameRate(selectedFps); if(effects.isNotEmpty())setEffects(Effects(emptyList(),effects)) }.build()
        val mime=if(codec.selectedItemPosition==1 && Build.VERSION.SDK_INT>=24) MimeTypes.VIDEO_H265 else MimeTypes.VIDEO_H264
        val encoder=DefaultEncoderFactory.Builder(this).setEnableFallback(true).apply { if(bps>0)setRequestedVideoEncoderSettings(VideoEncoderSettings.Builder().setBitrate(bps).build()) }.build()
        val listener=object:Transformer.Listener {
            override fun onCompleted(composition:Composition,exportResult:ExportResult){ try{save(out);status.text="Selesai! Video tersimpan di Movies/StatusPro.";Toast.makeText(this@MainActivity,"Video berhasil disimpan",Toast.LENGTH_LONG).show()}catch(e:Exception){status.text="Ekspor selesai, gagal menyimpan: ${e.localizedMessage}"}; finishUi() }
            override fun onError(composition:Composition,exportResult:ExportResult,exportException:ExportException){status.text="Gagal: ${exportException.localizedMessage?:"format/encoder tidak didukung"}. Coba H.264, 720p, bitrate 3 Mbps.";out.delete();finishUi()}
        }
        try { transformer=Transformer.Builder(this).setVideoMimeType(mime).setEncoderFactory(encoder).addListener(listener).build(); transformer!!.start(edited,out.absolutePath); status.text="Sedang memproses…"; updateProgress() } catch(e:Exception){status.text="Tidak dapat memulai: ${e.localizedMessage}";out.delete();finishUi()}
    }
    private fun updateProgress(){ val t=transformer?:return; val holder=ProgressHolder(); val state=t.getProgress(holder); if(state==Transformer.PROGRESS_STATE_WAITING_FOR_AVAILABILITY) status.text="Menunggu encoder…" else status.text="Sedang mengoptimalkan video… ${holder.progress}%"; window.decorView.postDelayed({if(transformer!=null)updateProgress()},700) }
    private fun finishUi(){ transformer=null; exportButton.isEnabled=selectedUri!=null; cancelButton.visibility=View.GONE }
    private fun save(file:File){ val values=ContentValues().apply{put(MediaStore.Video.Media.DISPLAY_NAME,"StatusPro_${System.currentTimeMillis()}.mp4");put(MediaStore.Video.Media.MIME_TYPE,"video/mp4");put(MediaStore.Video.Media.RELATIVE_PATH,"Movies/StatusPro");put(MediaStore.Video.Media.IS_PENDING,1)}; val dest=contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI,values)?:throw IllegalStateException("Gagal membuat file galeri"); try{contentResolver.openOutputStream(dest)?.use{o->FileInputStream(file).use{it.copyTo(o)}}?:throw IllegalStateException("Gagal menulis file");values.clear();values.put(MediaStore.Video.Media.IS_PENDING,0);contentResolver.update(dest,values,null,null)}catch(e:Exception){contentResolver.delete(dest,null,null);throw e}finally{file.delete()} }
    private fun bytes(n:Long)="${DecimalFormat("0.0").format(n/1048576.0)} MB"
    override fun onDestroy(){transformer?.cancel();super.onDestroy()}
}
