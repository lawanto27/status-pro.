# STATUS PRO v0.3.0

Android video optimizer, offline-first, no watermark.

## Included features
- Select local video with Android document picker.
- Read source resolution, duration and file size.
- Quick presets: WhatsApp 720p, High Quality 1080p, Small 480p, Balanced 720p.
- Output resolution: 480p / 720p / 1080p / Original.
- Output frame rate: original / 24 / 25 / 30 FPS.
- Requested video bitrate: 1.5 / 3 / 6 / 8 Mbps / automatic.
- H.264 and H.265 selection (H.265 depends on Android version and device encoder support; fallback is enabled).
- Keep or remove original audio.
- GPU brightness and contrast adjustment.
- Export progress text, cancel action, and save to Movies/StatusPro.
- Dark charcoal, orange, white and silver RIDEWORKS-inspired interface.

## Important limitations
- AI generative enhancement, denoise, sharpening and saturation controls are not included in this build. The POCO M3 is not assumed to have a suitable AI accelerator.
- The bitrate is a requested encoder setting. Android encoders may adjust/ignore it for compatibility or quality.
- Resolution is scaled while preserving aspect ratio. Actual codec support and export performance depend on the phone firmware and source file.
- Preview comparison is not included yet; selected-file metadata is shown before export.
- This is a debug APK workflow, not a signed Play Store release.

## Build APK with GitHub Actions
1. Upload/extract this project into the `status-pro` GitHub repository (project root must contain `settings.gradle.kts`, `build.gradle.kts`, and `app/`).
2. Commit and push to the `main` branch, or open **Actions** → **Build Status Pro APK** → **Run workflow**.
3. Wait for the workflow to finish successfully.
4. Open the completed workflow run, scroll to **Artifacts**, and download `status-pro-debug-apk`.
5. Extract the artifact ZIP and install `app-debug.apk` on Android. Allow installation from the browser/file manager if Android asks.

## Requirements
- JDK 17
- Gradle 8.13
- Android Gradle Plugin 8.7.3 (resolved by root build file)
- Android SDK platform 36
